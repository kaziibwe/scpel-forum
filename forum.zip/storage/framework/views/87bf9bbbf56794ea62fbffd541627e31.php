test
<?php /**PATH /home/kaziibwe/Desktop/phrunsys/theard/scpel-forum/resources/views/test.blade.php ENDPATH**/ ?>