<!-- Mobile view thread panel - BEGIN -->

<div class="mobile_container">
    <div class="mobile_side-panel hidden" id="mobile_sidePanel">
        <button class="mobile_close-btn" onclick="toggleSidePanel()">Close</button>
        <div class="w-full h-full">
            <div class="flex items-center justify-between mb-4">
                <h5 class="text-xl font-bold leading-none text-gray-900 dark:text-white">Latest Discussions</h5>
            </div>
            <div class="flow-root">
                <ul role="list" class="divide-y divide-gray-200 dark:divide-gray-700">



                    <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $id = $thread->id;
                        ?>
                        <a href="<?php echo e(route('home', $id)); ?>">
                            <li class="py-1 hover:bg-gray-100 cursor-pointer">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0">
                                        <img class="w-8 h-8 rounded-full"
                                            src="https://ui-avatars.com/api/?name=<?php echo e($thread->firstname); ?>+<?php echo e($thread->lastname); ?>&background=random"
                                            alt="Neil image">
                                    </div>
                                    <div class="flex-1 min-w-0 ms-4">
                                        <p class="text-sm font-medium text-gray-900 truncate dark:text-white">
                                            <?php echo e($thread->subject); ?>

                                        </p>

                                        <div class="mt-2 flex justify-between w-full pl-2 pr-2">
                                            <p class="text-sm text-gray-500 truncate dark:text-gray-400">
                                                by <?php echo e($thread->firstname); ?> <?php echo e($thread->firstname); ?>


                                            </p>
                                            <p class="text-sm text-gray-500 truncate dark:text-gray-400">
                                                <?php echo e($thread->created_at); ?>

                                            </p>
                                        </div>
                                    </div>
                                    <div class="flex-shrink-0">
                                        
                                        <?php if(auth()->guard()->check()): ?>
                                            <form action="<?php echo e(route('delete.thread', $id)); ?>" method="post">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                
                                                <button type="submit">
                                                    <img class="w-8 h-8 rounded-full" src="./icons8-delete-button.gif"
                                                        alt="Neil image">
                                                </button>

                                            </form>
                                        <?php endif; ?>


                                    </div>
                                </div>
                            </li>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <nav class="flex justify-center mt-4">
                        <ul class="flex list-reset border border-gray-300 rounded-sm">
                            <li class="relative block py-2 px-3 leading-tight bg-white border-r border-gray-300">
                                <a class="page-link" href="<?php echo e($threads->previousPageUrl()); ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>

                            <?php for($i = 1; $i <= $threads->lastPage(); $i++): ?>
                                <li
                                    class="relative block py-2 px-3 leading-tight <?php echo e($threads->currentPage() == $i ? 'bg-blue-500 text-white' : 'bg-white text-blue-500'); ?>">
                                    <a class="page-link" href="<?php echo e($threads->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>

                            <li class="relative block py-2 px-3 leading-tight bg-white border-l border-gray-300">
                                <a class="page-link" href="<?php echo e($threads->nextPageUrl()); ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Mobile view thread panel - END -->

<div class="mt-10 flex">

    <!-- Side Panel (left div) defaulr - BEGIN -->
    <div id="side_panel" class="w-1/5 flex flex-col p-2">
        <div class="w-full h-full">
            <div class="flex items-center justify-between mb-4">
                <h5 class="text-xl font-bold leading-none text-gray-900 dark:text-white">Latest Discussions</h5>
            </div>
            <div class="flow-root">
                <ul role="list" class="divide-y divide-gray-200 dark:divide-gray-700">

                    <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $id = $thread->id;
                        ?>
                        <a href="<?php echo e(route('home', $id)); ?>">
                            <li class="py-1 hover:bg-gray-100 cursor-pointer">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0">
                                        <img class="w-8 h-8 rounded-full"
                                            src="https://ui-avatars.com/api/?name=<?php echo e($thread->firstname); ?>+<?php echo e($thread->lastname); ?>&background=random"
                                            alt="Neil image">
                                    </div>
                                    <div class="flex-1 min-w-0 ms-4">
                                        <p class="text-sm font-medium text-gray-900 truncate dark:text-white">
                                            <?php echo e($thread->subject); ?>

                                        </p>

                                        <div class="mt-2 flex justify-between w-full pl-2 pr-2">
                                            <p class="text-sm text-gray-500 truncate dark:text-gray-400">
                                                by <?php echo e($thread->firstname); ?> <?php echo e($thread->firstname); ?>

                                            </p>
                                            <p class="text-sm text-gray-500 truncate dark:text-gray-400">
                                                <?php echo e($thread->created_at); ?>

                                            </p>
                                        </div>
                                    </div>
                                    <div class="flex-shrink-0">
                                        

                                        <?php if(auth()->guard()->check()): ?>
                                            <form action="<?php echo e(route('delete.thread', $id)); ?>" method="post">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                
                                                <button type="submit">
                                                    <img class="w-8 h-8 rounded-full" src="./icons8-delete-button.gif"
                                                        alt="Neil image">
                                                </button>

                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </li>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <nav class="flex justify-center mt-4">
                        <ul class="flex list-reset border border-gray-300 rounded-sm">
                            <li class="relative block py-2 px-3 leading-tight bg-white border-r border-gray-300">
                                <a class="page-link" href="<?php echo e($threads->previousPageUrl()); ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>

                            <?php for($i = 1; $i <= $threads->lastPage(); $i++): ?>
                                <li
                                    class="relative block py-2 px-3 leading-tight <?php echo e($threads->currentPage() == $i ? 'bg-blue-500 text-white' : 'bg-white text-blue-500'); ?>">
                                    <a class="page-link" href="<?php echo e($threads->url($i)); ?>"><?php echo e($i); ?></a>
                                </li>
                            <?php endfor; ?>

                            <li class="relative block py-2 px-3 leading-tight bg-white border-l border-gray-300">
                                <a class="page-link" href="<?php echo e($threads->nextPageUrl()); ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </ul>
            </div>
        </div>
    </div>
    <!-- Side Panel (left div) defaulr - END -->






<?php /**PATH /home/kaziibwe/Desktop/phrunsys/theard/scpel-forum/resources/views/partials/threads.blade.php ENDPATH**/ ?>